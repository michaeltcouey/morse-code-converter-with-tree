# morse code
Extract the contents of Morse Code Converter.zip 

This program creates a binary search tree out of morse code for the letters of the alphabet.

To encode a plain message into morse code, input it into "plain text in.txt" 
(only use lower case letters a-z and spaces) the output will write to "morse code out.txt".

To decode a morse code message into plain test, input the morse code into "morse text in.txt" 
(only use '.' , '_' , and ' ' spaces) the output will write to "plain text out.txt".